TERRITORY 21 CHARACTERS v2 -- SPLIT TRANSPORT FOR CODEX
Original archive: TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip
Original SHA256: d8bd7c242accd3396232a53cae7fe47478c4b6aae558b95dbad0c68edf5c1fa1
Parts: TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip.part01, .part02, .part03
Attach ALL THREE of these ZIP packages to the same Codex task.
Unpack all 3 ZIP packages into ONE directory (e.g., /tmp/territory-art-parts/).
Then reconstruct the original byte-exact archive:
    cat /tmp/territory-art-parts/TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip.part0[123] > /tmp/TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip
    echo 'd8bd7c242accd3396232a53cae7fe47478c4b6aae558b95dbad0c68edf5c1fa1  /tmp/TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip' | sha256sum -c -
Run the repo's existing importer:
    node scripts/import-approved-characters-v2.mjs /tmp/TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip --dry-run
    node scripts/import-approved-characters-v2.mjs /tmp/TERRITORY_21_CHARACTERS_QA_PACK_2026-11-11_v2.zip
Use the current PR #491 branch. Import ONLY to staging new paths, do not modify live game or production Supabase.
